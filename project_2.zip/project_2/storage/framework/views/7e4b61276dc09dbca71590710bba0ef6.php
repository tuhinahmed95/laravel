
<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h4>Hello <?php echo e(auth()->user()->email); ?></h4>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partial.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mosharrof Hosain\Desktop\text-project\project_2\resources\views\admin\page\dashboard.blade.php ENDPATH**/ ?>