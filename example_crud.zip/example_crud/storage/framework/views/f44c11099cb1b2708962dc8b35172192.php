<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="bg-info">Singel User Details</h3>
    </div>
    <table class="table table-striped">
        <tr>
            <th>Name :</th>
            <td><?php echo e($user->name); ?></td>
        </tr>

        <tr>
            <th>Email :</th>
            <td><?php echo e($user->email); ?></td>
        </tr>

        <tr>
            <th>Age :</th>
            <td><?php echo e($user->age); ?></td>
        </tr>

        <tr>
            <th>City :</th>
            <td><?php echo e($user->city); ?></td>
        </tr>

    </table>
    <a href="<?php echo e(route('user.index')); ?>" class="btn btn-success">Back</a>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\example_crud\resources\views/singleuser.blade.php ENDPATH**/ ?>