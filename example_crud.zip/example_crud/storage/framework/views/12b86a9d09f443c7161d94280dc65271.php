<?php $__env->startSection('content'); ?>
<h3><a href="<?php echo e(route('user.create')); ?>" class="btn btn-success text-light">Add New User</a></h3>

<div class="card">
    <div class="card-header">
        <h3>All Users Here</h3>
    </div>
    <div class="card-body">
        <table class="table table-striped table-borderd">
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Age</th>
                <th>City</th>
                <th>View</th>
                <th>Update</th>
                <th>Delete</th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->age); ?></td>
                    <td><?php echo e($user->city); ?></td>
                    <td><a href="<?php echo e(route('user.show',$user->id)); ?>" class="btn btn-warning">View</a></td>
                    <td><a href="<?php echo e(route('user.edit',$user->id)); ?>" class="btn btn-success">Update</a></td>
                    <td>
                        <form action="<?php echo e(route('user.destroy',$user->id)); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\example_crud\resources\views/home.blade.php ENDPATH**/ ?>