<?php $__env->startSection('title'); ?>
    All Users Data
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('user.create')); ?>" class="btn btn-success">Create New User</a>
<div class="card">
    <div class="card-header">
        <h3 class="bg-info">All Users Here</h3>
    </div>
    <div class="card-body">
        <table class="table table-striped">
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Age</th>
                <th>City</th>
                <th>View</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->age); ?></td>
                    <td><?php echo e($user->city); ?></td>
                    <td><a href="<?php echo e(route('user.show',$user->id)); ?>" class="btn btn-success">View</a></td>
                    <td><a href="<?php echo e(route('user.edit',$user->id)); ?>" class="btn btn-warning text-light">Edit</a></td>
                    <td><a href="#" class="btn btn-danger">Delete</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\practice-c\resources\views\home.blade.php ENDPATH**/ ?>