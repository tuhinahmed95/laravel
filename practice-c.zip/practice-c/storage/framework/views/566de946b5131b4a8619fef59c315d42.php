<?php $__env->startSection('title'); ?>
Single user Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3>Single User Information</h3>
    </div>
    <div class="card-body">
        <table class="table table-borderd">
            <tr>
                <th>Name :</th>
                <td><?php echo e($user->name); ?></td>
            </tr>

            <tr>
                <th>Email :</th>
                <td><?php echo e($user->email); ?></td>
            </tr>

            <tr>
                <th>Age :</th>
                <td><?php echo e($user->age); ?></td>
            </tr>

            <tr>
                <th>City :</th>
                <td><?php echo e($user->city); ?></td>
            </tr>
        </table>
        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-success">Back</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\practice-c\resources\views\viewuser.blade.php ENDPATH**/ ?>